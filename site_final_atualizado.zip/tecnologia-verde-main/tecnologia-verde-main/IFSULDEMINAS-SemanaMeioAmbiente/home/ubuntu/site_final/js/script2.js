// Scripts gerais do site (se necessário no futuro)
document.addEventListener("DOMContentLoaded", () => {
    console.log("Site IFSULDEMINAS Meio Ambiente carregado.");
    // Adicionar aqui eventuais interações globais ou manipulações de DOM
});
