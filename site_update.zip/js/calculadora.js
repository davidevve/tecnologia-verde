// Calculadora de Pegada de Carbono
function calcularPegada() {
    // Obter valores do formulário
    const transporteTipo = document.getElementById('transporteTipo').value;
    const transporteDistancia = parseFloat(document.getElementById('transporteDistancia').value) || 0;
    const energiaConsumo = parseFloat(document.getElementById('energiaConsumo').value) || 0;
    const gasConsumo = parseFloat(document.getElementById('gasConsumo').value) || 0;
    
    // Fatores de emissão (kg CO2e)
    const fatores = {
        gasolina: 0.22, // kg CO2e por km
        alcool: 0.18,   // kg CO2e por km
        moto: 0.12,     // kg CO2e por km
        onibus: 0.05,   // kg CO2e por passageiro-km
        nenhum: 0,      // kg CO2e
        energia: 0.09,  // kg CO2e por kWh (média brasileira)
        gas: 38         // kg CO2e por botijão de 13kg
    };
    
    // Cálculo das emissões mensais
    let emissaoTransporte = 0;
    if (transporteTipo !== 'nenhum') {
        emissaoTransporte = transporteDistancia * fatores[transporteTipo] * 30; // 30 dias por mês
    }
    
    const emissaoEnergia = energiaConsumo * fatores.energia;
    const emissaoGas = gasConsumo * fatores.gas;
    
    // Total de emissões
    const totalEmissoes = emissaoTransporte + emissaoEnergia + emissaoGas;
    
    // Exibir resultado
    const resultadoDiv = document.getElementById('resultadoCalculadora');
    
    // Interpretação do resultado
    let interpretacao = "";
    if (totalEmissoes < 100) {
        interpretacao = "Sua pegada está abaixo da média brasileira (cerca de 200 kg CO2e/mês). Continue com os bons hábitos sustentáveis!";
    } else if (totalEmissoes < 200) {
        interpretacao = "Sua pegada está próxima da média brasileira. Há espaço para melhorias, especialmente em transporte e consumo de energia.";
    } else if (totalEmissoes < 400) {
        interpretacao = "Sua pegada está acima da média brasileira e global. Considere alternativas de transporte mais sustentáveis e reduza seu consumo energético.";
    } else {
        interpretacao = "Sua pegada é significativamente alta. Recomendamos revisar seus hábitos de consumo, especialmente relacionados a transporte e energia.";
    }
    
    resultadoDiv.innerHTML = `
        <h4>Resultado da sua Pegada de Carbono</h4>
        <p>Sua pegada de carbono mensal estimada é de aproximadamente: <strong>${totalEmissoes.toFixed(2)} kg CO2e</strong>.</p>
        <p><strong>O que isso significa?</strong> ${interpretacao}</p>
        <p><strong>Contexto:</strong> A média brasileira é de aproximadamente 200 kg CO2e por pessoa por mês, enquanto a média mundial é de cerca de 300 kg CO2e.</p>
        <h4>Dicas para Reduzir sua Pegada:</h4>
        <ul>
            <li>Utilize transporte público, bicicleta ou caminhada sempre que possível;</li>
            <li>Desligue aparelhos eletrônicos quando não estiverem em uso;</li>
            <li>Opte por eletrodomésticos com selo de eficiência energética;</li>
            <li>Reduza o consumo de carne vermelha;</li>
            <li>Prefira produtos locais e sazonais.</li>
        </ul>
    `;
}
