// Modified script for IF Suldminas Sustentavel

document.addEventListener('DOMContentLoaded', function() {
    // --- Global variables for tab management ---
    const tabLinks = document.querySelectorAll('nav .tab-link, .tab-link-card');
    const tabContents = document.querySelectorAll('.tab-content');
    const tabContentWrapper = document.getElementById('tab-content-wrapper');
    let currentTabHash = '#inicio'; // Track the logically active tab hash

    // --- Tab Switching Logic (Visuals Only) ---
    function switchTab(targetId) {
        // Normalize hash
        if (targetId && !targetId.startsWith('#')) {
             targetId = '#' + targetId.split('#').pop();
        }
        if (!targetId || targetId === '#') targetId = '#inicio';

        console.log(`Switching visual tab to: ${targetId}`); // Debugging

        tabContents.forEach(content => {
            content.classList.remove('active-content');
        });
        tabLinks.forEach(link => {
            link.classList.remove('active-tab');
            const linkHref = link.getAttribute('href');
            if (linkHref && (linkHref === targetId || linkHref.endsWith(targetId))) {
                link.classList.add('active-tab');
            }
        });

        const activeContent = document.querySelector(targetId);
        if (activeContent) {
            activeContent.classList.add('active-content');
        } else {
            console.warn(`Content not found for: ${targetId}, defaulting to #inicio`);
            const inicioContent = document.querySelector('#inicio');
            if (inicioContent) inicioContent.classList.add('active-content');
            const inicioLink = document.querySelector('nav a[href="index.html#inicio"], nav a[href="#inicio"]');
             if (inicioLink) inicioLink.classList.add('active-tab');
        }

        // Fade-in effect
        if (tabContentWrapper) {
            tabContentWrapper.style.opacity = '0';
            setTimeout(() => {
                tabContentWrapper.style.opacity = '1';
            }, 50);
        }
    }

    // --- Function to Set Active Tab (Logic + History) ---
    function setActiveTab(targetHash, updateHistory = true, historyMethod = 'pushState') {
        if (!targetHash || targetHash === '#') targetHash = '#inicio';

        const isValidTab = Array.from(tabLinks).some(link => {
            const href = link.getAttribute('href');
            return href && (href === targetHash || href.endsWith(targetHash));
        });
        if (!isValidTab) {
            console.warn(`Invalid tab target: ${targetHash}. Defaulting to #inicio.`);
            targetHash = '#inicio';
        }

        // Only proceed if target is different from current
        if (targetHash === currentTabHash && updateHistory) {
             console.log(`Target tab ${targetHash} is already active.`);
             // Optional: Scroll to top of section even if active
             scrollToSection(targetHash);
             return; // Don't update history if already active
        }

        switchTab(targetHash); // Update visuals

        const previousTabHash = currentTabHash;
        currentTabHash = targetHash; // Update global tracker
        console.log(`Logical tab updated: from ${previousTabHash} to ${targetHash}`);

        if (updateHistory) {
            const currentBrowserHash = window.location.hash || '#inicio';
            if (targetHash !== currentBrowserHash) {
                 if (historyMethod === 'pushState') {
                     history.pushState({ tab: targetHash }, "", targetHash);
                     console.log(`Pushed state: ${targetHash}`);
                 } else {
                     history.replaceState({ tab: targetHash }, "", targetHash);
                     console.log(`Replaced state: ${targetHash}`);
                 }
            } else {
                 console.log("History state already matches target hash.");
            }
        }

        // Scrolling needs to happen *after* visual switch
        scrollToSection(targetHash);
    }

    // --- Scrolling Function ---
    function scrollToSection(targetHash) {
         if (targetHash !== '#inicio') {
            const headerHeight = document.querySelector('header')?.offsetHeight || 0;
            const targetElement = document.querySelector(targetHash);
            if(targetElement) {
                const elementPosition = targetElement.getBoundingClientRect().top + window.pageYOffset;
                const offsetPosition = elementPosition - headerHeight - 20; // 20px margin
                window.scrollTo({ top: offsetPosition, behavior: 'smooth' });
            }
        } else {
             window.scrollTo({ top: 0, behavior: 'smooth' });
        }
    }

    // --- Click Handler for Tab Links ---
    tabLinks.forEach(link => {
        link.addEventListener('click', function(event) {
            event.preventDefault();
            const targetId = this.getAttribute('href');
            const targetHash = '#' + targetId.split('#').pop();

            // Use setActiveTab to handle logic, visuals, and history
            // Push state for all tabs to ensure back button works predictably initially
            setActiveTab(targetHash, true, 'pushState');
        });
    });

    // --- Popstate Handler (Browser Back/Forward) ---
    window.addEventListener('popstate', function(event) {
        const previousHashBeforePop = currentTabHash; // The tab active *before* back/forward
        const stateTargetHash = (event.state && event.state.tab) ? event.state.tab : (window.location.hash || '#inicio');

        console.log(`Popstate: Previous Active: ${previousHashBeforePop}, State Target: ${stateTargetHash}`);

        // Rule: If we *were* on Tech Verde or Acoes, and popstate is taking us *away* from them, go to Inicio instead.
        if ((previousHashBeforePop === '#tecnologia-verde' || previousHashBeforePop === '#acoes') && stateTargetHash !== previousHashBeforePop) {
            console.log("Rule triggered: Back from Tech Verde/Acoes.");
            // Force the state to #inicio
            setActiveTab('#inicio', true, 'replaceState'); // Replace history to reflect #inicio, update visuals/tracker
            console.log("Forced state to #inicio.");
        } else {
            // Normal popstate: Go to the state's target tab
            console.log(`Normal popstate: Setting active tab to ${stateTargetHash}`);
            // Update visuals and tracker, but DON'T modify history again
            setActiveTab(stateTargetHash, false);
        }
    });

    // --- Initial Page Load Setup ---
    // Simulação de contador animado (Keep original)
    const contadorNumero = document.getElementById('contador-numero');
    if (contadorNumero) {
        let valorFinal = 75; // Valor ilustrativo
        let valorAtual = 0;
        const incremento = Math.ceil(valorFinal / 100);
        function animarContador() {
            if (valorAtual < valorFinal) {
                valorAtual += incremento;
                if (valorAtual > valorFinal) valorAtual = valorFinal;
                contadorNumero.textContent = valorAtual;
                setTimeout(animarContador, 20);
            } else {
                contadorNumero.textContent = valorFinal;
            }
        }
        animarContador();
    }

    // Initialize the correct tab based on the initial hash
    const initialHash = window.location.hash || '#inicio';
    setActiveTab(initialHash, true, 'replaceState'); // Set initial state, replace history

    console.log('Script loaded, DOM ready, history/tab logic initialized.');

}); // End DOMContentLoaded


// --- Calculadora de Pegada de Carbono (Keep original) ---
function calcularPegada() {
    const transporteTipo = document.getElementById('transporteTipo').value;
    const transporteDistancia = parseFloat(document.getElementById('transporteDistancia').value) || 0;
    const energiaConsumo = parseFloat(document.getElementById('energiaConsumo').value) || 0;
    const gasConsumo = parseFloat(document.getElementById('gasConsumo').value) || 0;

    let emissoesTransporte = 0;
    const diasNoMes = 30;

    const fatorGasolina = 0.18;
    const fatorAlcool = 0.10;
    const fatorMoto = 0.09;
    const fatorOnibus = 0.085;
    const fatorEnergia = 0.075;
    const fatorGasGLP = 35.9;

    if (transporteTipo !== 'nenhum') {
        let fatorTransporteSelecionado = 0;
        switch (transporteTipo) {
            case 'gasolina': fatorTransporteSelecionado = fatorGasolina; break;
            case 'alcool': fatorTransporteSelecionado = fatorAlcool; break;
            case 'moto': fatorTransporteSelecionado = fatorMoto; break;
            case 'onibus': fatorTransporteSelecionado = fatorOnibus; break;
        }
        emissoesTransporte = transporteDistancia * fatorTransporteSelecionado * diasNoMes;
    }

    const emissoesEnergia = energiaConsumo * fatorEnergia;
    const emissoesGas = gasConsumo * fatorGasGLP;
    const emissoesTotais = emissoesTransporte + emissoesEnergia + emissoesGas;

    const resultadoDiv = document.getElementById('resultadoCalculadora');
    resultadoDiv.innerHTML = `<p>Sua pegada de carbono mensal estimada é de aproximadamente: <strong>${emissoesTotais.toFixed(2)} kg CO2e</strong>.</p>\n                            <p><small>Este é um cálculo simplificado. Fatores como tipo de veículo específico, eficiência energética de aparelhos, origem da energia e hábitos de consumo detalhados podem alterar significativamente este valor.</small></p>`;
}

// --- Quiz Logic (Assuming quiz.js handles its own logic) ---
// No changes needed here unless quiz interacts with main tabs/history

